import assert from 'node:assert/strict';
import { readFileSync, readdirSync, lstatSync, existsSync } from 'node:fs';
import { join, resolve, dirname, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { inflateSync } from 'node:zlib';
import { runInNewContext } from 'node:vm';
import { buildDossier } from '../vendor/makefun-board.ts';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const out = resolve(process.argv[2] || root),
  snapshotFile = resolve(process.argv[3] || join(root, 'data/snapshot.json'));
const snapshotBytes = readFileSync(snapshotFile),
  snapshot = JSON.parse(snapshotBytes);
const digest = (b) => createHash('sha256').update(b).digest('hex');
const get = (p) => readFileSync(join(out, p));
const checks = {};
const gate = (name, test) => {
  checks[name] = test();
};
const validName = /^[a-zA-Z0-9_][a-zA-Z0-9._-]{0,127}$/;
const rows = JSON.parse(get('board.json')).rows;
const bySlug = new Map(snapshot.protocols.map((p) => [p.slug, p]));
const textCap = 65536;
function walk(dir) {
  return readdirSync(dir).flatMap((name) => {
    assert.ok(validName.test(name), name);
    const path = join(dir, name),
      stat = lstatSync(path);
    assert.ok(!stat.isSymbolicLink() && (stat.isFile() || stat.isDirectory()), path);
    return stat.isDirectory() ? walk(path) : [path];
  });
}
gate('dashboard_files', () => {
  const base = join(out, 'dashboard'),
    files = walk(base),
    bytes = files.reduce((sum, p) => sum + lstatSync(p).size, 0);
  assert.ok(
    existsSync(join(base, 'index.html')) &&
      files.some((p) => p.endsWith('.css')) &&
      files.some((p) => p.endsWith('.js')),
  );
  assert.ok(files.length <= 400 && bytes <= 4194304);
  for (const f of files) {
    const src = readFileSync(f, 'utf8');
    // This edition requires no remote URL even in the dashboard source itself.
    assert.doesNotMatch(src, /https?:\/\//i, relative(base, f));
  }
  return { files: files.length, bytes };
});
gate('board_file', () => {
  assert.ok(rows.length >= 100 && rows.length <= 4000 && get('board.json').length <= 8388608);
  assert.equal(new Set(rows.map((p) => p.slug)).size, rows.length);
  for (const p of rows) {
    assert.ok(/^\S{1,128}$/.test(p.slug) && bySlug.has(p.slug) && p.name.trim().length > 0);
    assert.ok(Number.isSafeInteger(p.implied_value_usd) && p.implied_value_usd > 0 && p.implied_value_usd <= 1e14);
    assert.ok(Array.isArray(p.farm_steps));
  }
  return { rows: rows.length, bytes: get('board.json').length };
});
gate('sorted_by_value', () => {
  rows.forEach((p, i) => {
    assert.equal(p.rank, i + 1);
    if (i) assert.ok(p.implied_value_usd <= rows[i - 1].implied_value_usd);
  });
  assert.ok(rows[0].implied_value_usd > rows.at(-1).implied_value_usd);
  return { first: rows[0].slug, last: rows.at(-1).slug };
});
gate('coverage', () => {
  const slugs = new Set(rows.map((p) => p.slug));
  assert.ok(snapshot.watchlist.every((s) => slugs.has(s)));
  for (const p of rows) {
    const src = bySlug.get(p.slug);
    assert.equal(src.symbol, null);
    assert.equal(src.gecko_id, null);
  }
  return { watchlist: snapshot.watchlist.length, covered: snapshot.watchlist.filter((s) => slugs.has(s)).length };
});
gate('farm_steps', () => {
  for (const p of rows) {
    assert.ok(p.farm_steps.length >= 3 && p.farm_steps.length <= 12);
    assert.ok(p.farm_steps.every((s) => typeof s === 'string' && s.trim().length >= 20 && s.trim().length <= 600));
  }
  return { plans: rows.length, total_steps: rows.reduce((s, p) => s + p.farm_steps.length, 0) };
});
function pngSize(b) {
  assert.ok(b.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])));
  let pos = 8,
    header = false,
    end = false,
    w = 0,
    h = 0,
    depth = 0,
    color = 0;
  const content = [];
  while (pos < b.length) {
    const len = b.readUInt32BE(pos),
      type = b.toString('ascii', pos + 4, pos + 8);
    assert.ok(pos + 12 + len <= b.length);
    const data = b.subarray(pos + 8, pos + 8 + len);
    if (!header) {
      assert.equal(type, 'IHDR');
      assert.equal(len, 13);
      w = data.readUInt32BE(0);
      h = data.readUInt32BE(4);
      depth = data[8];
      color = data[9];
      assert.equal(data[12], 0);
      header = true;
    }
    if (type === 'IDAT') content.push(data);
    pos += 12 + len;
    if (type === 'IEND') {
      assert.equal(len, 0);
      end = true;
      break;
    }
  }
  assert.ok(end && pos === b.length && content.length > 0);
  const channels = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[color];
  assert.ok(channels);
  const pixels = inflateSync(Buffer.concat(content));
  assert.equal(pixels.length, h * (1 + Math.ceil((w * channels * depth) / 8)));
  return [w, h];
}
gate('screenshots', () => {
  const names = readdirSync(join(out, 'screenshots')).sort();
  assert.equal(names.length, 3);
  return names.map((name) => {
    assert.ok(validName.test(name));
    const b = get('screenshots/' + name);
    assert.ok(b.length <= 524288);
    const [w, h] = pngSize(b);
    assert.ok(Math.min(w, h) >= 800 && Math.max(w, h) <= 1440);
    return { name, width: w, height: h, bytes: b.length, sha256: digest(b) };
  });
});
gate('dossier_matches', () => {
  const official = buildDossier(out, { text_max_bytes: textCap }),
    actual = get('dossier.json');
  assert.deepEqual(Buffer.from(official), actual);
  assert.ok(actual.length <= 1572864);
  const dossier = JSON.parse(actual);
  assert.doesNotMatch(dossier.text, /\[Cut at 65536 bytes:/);
  return {
    bytes: actual.length,
    dashboard_text_bytes: Buffer.byteLength(dossier.text),
    sha256: digest(actual),
    complete_source: true,
  };
});
const env = {};
runInNewContext(get('data.js').toString('utf8'), env);
const data = env.MERIDIAN_DATA,
  all = [...data.rows, ...data.recorded, ...data.aside];
assert.equal(JSON.stringify(data.rows), JSON.stringify(rows));
assert.equal(all.length, snapshot.protocols.length);
assert.equal(new Set(all.map((p) => p.slug)).size, bySlug.size);
assert.ok(all.every((p) => bySlug.has(p.slug)));
assert.equal(data.metadata.snapshot_sha256, digest(snapshotBytes));
for (const p of rows) {
  const v = p.valuation;
  assert.ok(v.low <= p.implied_value_usd && v.high >= p.implied_value_usd);
  assert.equal(Math.round(p.tvl_usd * v.multiple * v.growth_factor * v.age_factor), p.implied_value_usd);
  if (p.cohort === 'Watchlist') assert.equal(p.farm.source_grade, 'Named product research');
  if (p.cohort === 'Below floor') assert.ok(p.tvl_usd < snapshot.floor_usd);
}
const vendorHash = digest(readFileSync(join(root, 'vendor/makefun-board.ts')));
assert.equal(vendorHash, '9ca51b6e5cd84fe46cb0efa61e2ea99365a1fb0e21f2b75e6007f977f0dc326e');
console.log(
  JSON.stringify(
    {
      result: 'pass',
      kind: 'Local independent checks against the seven published file rules',
      node: process.version,
      snapshot_sha256: digest(snapshotBytes),
      vendor_sha256: vendorHash,
      checks,
      full_ledger: all.length,
    },
    null,
    2,
  ),
);
