"""Capture the actual file:// dashboard with networking disabled. Optional development tool."""
import argparse
import json
import os
from pathlib import Path
import shutil
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--root", type=Path, default=root)
parser.add_argument("--dest", type=Path)
opts = parser.parse_args()
base = opts.root.resolve()
dest = opts.dest or base / "screenshots"
dest.mkdir(parents=True, exist_ok=True)
expected = json.loads((base / "board.json").read_text())
with sync_playwright() as engine:
    binary = os.environ.get("CHROME_BIN") or shutil.which("chromium") or shutil.which("google-chrome")
    browser = engine.chromium.launch(executable_path=binary, args=["--no-sandbox"])
    ctx = browser.new_context(viewport={"width": 1440, "height": 960}, device_scale_factor=1, offline=True, reduced_motion="reduce")
    page = ctx.new_page()
    errors, external = [], []
    page.on("pageerror", lambda err: errors.append(str(err)))
    page.on("request", lambda req: external.append(req.url) if req.url.startswith(("http:", "https:", "ws:", "wss:")) else None)
    page.goto((base / "dashboard/index.html").as_uri())
    page.get_by_role("heading", name="Token launch radar").wait_for()
    leader = expected["rows"][0]
    assert page.locator("tbody tr").first.get_attribute("data-row") == leader["slug"]
    page.screenshot(path=str(dest / "1-board.png"), animations="disabled")
    page.get_by_role("link", name=leader["name"], exact=True).click()
    page.get_by_role("heading", name="Farm playbook").wait_for()
    assert page.locator(".steps li").count() == len(leader["farm_steps"])
    assert page.locator(".steps li p").all_text_contents() == leader["farm_steps"]
    page.mouse.move(0,0)
    page.screenshot(path=str(dest / "2-detail.png"), animations="disabled")
    page.get_by_role("link", name="← Ranked protocols").click()
    page.get_by_role("button", name="Below floor").click()
    page.locator("#filter-category").select_option("Lending")
    page.wait_for_function("document.querySelector('.selection')?.textContent.includes('Lending')")
    page.locator("#filter-category").blur()
    page.mouse.move(0,0)
    matches = [x for x in expected["rows"] if x["category"] == "Lending" and x["cohort"] == "Below floor"]
    assert int(page.locator(".sectionhead .total").inner_text()) == len(matches)
    page.screenshot(path=str(dest / "3-filtered.png"), animations="disabled")
    assert not errors, errors
    assert not external, external
    print(json.dumps({"screenshots":3,"viewport":[1440,960],"leader":leader["slug"],
                      "filtered":{"cohort":"Below floor","category":"Lending","matches":len(matches)},
                      "http_requests":external, "page_errors":errors}))
    browser.close()

