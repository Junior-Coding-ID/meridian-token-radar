# Rencana farm untuk 147 protokol

Urutan mengikuti estimasi kapitalisasi beredar dalam snapshot 14 November 2026. Anggaran adalah batas contoh dan seluruh biaya memakai USD. Cek harga serta ketersediaan hari ini di kanal resmi. Setiap kandidat memiliki enam langkah dan referensi. Bagian rujukan produk memakai uji kelayakan awal. Kandidat di bawah ambang memakai panduan berbasis kategori.

## 1. Steakhouse Financial

**Watchlist resmi** · Risk Curators · Base · **US$780.002.891** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Steakhouse Financial dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Buka direktori kurator Morpho, pilih Steakhouse Financial dan Base, lalu cari vault USDC. Cocokkan alamat vault, daftar jaminan, tingkat risiko, biaya, dan USDC yang siap ditarik.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Morpho · Steakhouse curator directory](https://app.morpho.org/curator/steakhouse-financial)

## 2. Gauntlet

**Watchlist resmi** · Risk Curators · Base · **US$459.064.859** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Gauntlet dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Lihat Gauntlet WETH Core di Base. Cocokkan alamat vault Morpho dan cek limit jaminan serta likuiditas WETH. Biaya membungkus ETH, jika perlu, masuk ke anggaran.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Morpho · Gauntlet WETH Core on Base](https://app.morpho.org/base/vault/0x6b13c060F13Af1fdB319F52315BbbF3fb1D88844/gauntlet-weth-core)

## 3. USDD

**Watchlist resmi** · CDP · Tron · **US$186.409.982** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi USDD dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa dua arah konversi di Peg Stability Module USDD pada jaringan yang didukung. USDD sudah berfungsi sebagai stablecoin. Estimasi di radar berlaku untuk token protokol hipotetis yang terpisah.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Bandingkan harga serta unit di dua arah konversi PSM secara read-only.
5. Periksa kedalaman likuiditas, biaya jaringan dan apa yang terjadi saat likuiditas penebusan habis.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [USDD · peg stability module](https://docs.usdd.io/user-guide/psm-peg-stability-module)

## 4. Veda

**Watchlist resmi** · Onchain Capital Allocator · Base · **US$143.804.686** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Veda dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih vault mitra yang menyebut Veda. Cocokkan Teller, token saham dan antrean BoringQueue. Catat waktu jatuh tempo permintaan, diskon solver dan kondisi penyelesaian.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Veda · Boring Queue integration](https://sdk.veda.tech/docs/boring-queue-ui-integration)

## 5. Bittensor dTAO

**Watchlist resmi** · Dexs · Bittensor · **US$138.974.381** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Bittensor dTAO dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pisahkan unit TAO dan alpha subnet. Pilih satu subnet, catat likuiditas, lalu bandingkan kuotasi TAO ke alpha dan arah balik pada dua ukuran. Simpan ID subnet.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Kuotasi di dua arah dengan dua ukuran untuk mengukur dampak harga secara read-only.
5. Catat netuid, waktu, fee dan selisih unit setelah simulasi putaran penuh.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Learn Bittensor · slippage](https://guides.learnbittensor.org/staking-and-delegation/slippage)

## 6. Nonce Capital

**Watchlist resmi** · Risk Curators · Optimism · **US$123.122.280** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Nonce Capital dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa produk ether.fi Liquid atau Midas di Optimism yang tercatat dikelola Nonce. Telusuri underlying, aset dana, dan kontrak yang benar-benar mengkredit dompet.
3. Contoh maksimum pokok US$25 yang sudah ada di Optimism. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [DefiLlama · Nonce Capital adapter methodology](https://defillama.com/protocol/nonce-capital)

## 7. OnRe

**Watchlist resmi** · RWA · Solana · **US$82.597.922** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi OnRe dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Baca syarat Qualified Acquirer dan KYC/KYB untuk partisipasi langsung. Untuk ONyc, periksa eksposur reasuransi, ketentuan akun dan jalur penebusan.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Baca minimum, biaya, metode custody dan dokumen subscription. Catat apakah akses tersedia untuk situasimu.
5. Catat jadwal penebusan, aset settlement dan pihak lawan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [OnRe · regulatory framework](https://docs.onre.finance/legal)

## 8. RockawayX

**Watchlist resmi** · Risk Curators · Base · **US$78.065.143** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi RockawayX dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih vault RockawayX yang muncul di direktori Morpho. Bedakan aset setoran dari eksposur ekosistem dan baca berapa banyak aset yang bisa ditarik.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Morpho · RockawayX directory](https://app.morpho.org/curator/rockawayx)

## 9. OpenTrade

**Watchlist resmi** · RWA · Ethereum · **US$65.934.462** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi OpenTrade dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Baca syarat onboarding institusi. Catat badan hukum yang boleh berlangganan, negara yang didukung, minimum, cut-off dan ketentuan penebusan.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Baca minimum, biaya, metode custody dan dokumen subscription. Catat apakah akses tersedia untuk situasimu.
5. Catat jadwal penebusan, aset settlement dan pihak lawan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [OpenTrade · institutional onboarding](https://docs.opentrade.io/)

## 10. Hyperithm

**Watchlist resmi** · Risk Curators · Arbitrum · **US$62.280.454** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Hyperithm dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Gunakan direktori Hyperithm di Morpho. Cocokkan chain dan aset dasar. Bandingkan persentase jaminan terbesar dan likuiditas yang bisa keluar.
3. Contoh maksimum pokok US$25 yang sudah ada di Arbitrum. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Morpho · Hyperithm directory](https://app.morpho.org/curator/hyperithm)

## 11. Plume Vaults

**Watchlist resmi** · RWA · Plume Mainnet · **US$57.693.888** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Plume Vaults dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Bandingkan dua vault aset dunia nyata di direktori Plume. Catat penerbit, kelas investor, unit token vault dan periode penebusan masing-masing.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Baca minimum, biaya, metode custody dan dokumen subscription. Catat apakah akses tersedia untuk situasimu.
5. Catat jadwal penebusan, aset settlement dan pihak lawan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Plume · vault directory](https://app.plume.org/vaults)

## 12. K3 Capital

**Watchlist resmi** · Risk Curators · Arbitrum · **US$57.384.388** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi K3 Capital dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari K3 Capital di direktori kurator Morpho. Catat jaringan, konsentrasi pasar terbesar dan batas yang boleh dialokasikan ke pasar itu.
3. Contoh maksimum pokok US$25 yang sudah ada di Arbitrum. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Morpho · K3 Capital directory](https://app.morpho.org/curator/k3-capital)

## 13. R25

**Watchlist resmi** · RWA · Sui · **US$49.925.760** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi R25 dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Di Sui, pisahkan rcUSD dan posisi berimbal hasil rcUSDp. Periksa pihak yang boleh menebus serta aset yang akhirnya diterima.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Baca minimum, biaya, metode custody dan dokumen subscription. Catat apakah akses tersedia untuk situasimu.
5. Catat jadwal penebusan, aset settlement dan pihak lawan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Sui · R25 on Sui](https://www.sui.io/blog/r25-rwa-assets-rcusd-rcusdp)

## 14. Upshift

**Watchlist resmi** · Onchain Capital Allocator · Base · **US$49.073.609** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Upshift dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa apakah vault Upshift memakai allowlist dan penebusan instan atau antrean. Untuk jalur antrean, catat ID permintaan dan tanggal aset dapat diklaim.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Upshift · vault lifecycle](https://docs.upshift.finance/introduction/integration-guide)

## 15. Tori Finance

**Watchlist resmi** · Basis Trading · Ethereum · **US$46.911.695** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Tori Finance dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Baca cara posisi trading menopang trUSD. Bandingkan mekanisme penebusan trUSD dengan keluar dari posisi penghasil imbal hasil. Catat pihak yang memegang agunan.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Tori Finance · synthetic dollar](https://www.tori.finance/)

## 16. Symbiotic

**Watchlist resmi** · Collateral Markets · Ethereum · **US$44.908.671** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Symbiotic dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu vault Ethereum. Catat collateral, panjang epoch, jaringan delegasi, modul slashing, serta perbedaan permintaan withdrawal dan klaim akhir.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Periksa kuotasi masuk dan modelkan dampak penalti terhadap saldo. Catat siapa yang berhak menarik.
5. Petakan urutan meminta penarikan, menunggu dan mengklaim beserta waktu paling awal yang didokumentasikan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Symbiotic · vaults and epochs](https://docs.symbiotic.fi/learn/core-concepts/vault)

## 17. Clearstar

**Watchlist resmi** · Risk Curators · Base · **US$44.487.763** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Clearstar dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa Clearstar USDC Reactor di Base. Bandingkan limit alokasi tiap pasar, saldo USDC yang tersedia untuk keluar, dan saham yang ditawarkan.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Morpho · Clearstar USDC Reactor on Base](https://app.morpho.org/base/vault/0x1D3b1Cd0a0f242d598834b3F2d126dC6bd774657/clearstar-usdc-reactor)

## 18. Axis

**Watchlist resmi** · Basis Trading · Ethereum · **US$41.103.323** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Axis dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Bedakan USDx dari vault sUSDx. Telusuri risiko basis antar-bursa dan siapa yang memproses penebusan jika likuiditas di salah satu bursa menurun.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [DefiLlama · Axis product description](https://defillama.com/protocol/axis)

## 19. Saturn

**Watchlist resmi** · Stablecoin Wrapper · Ethereum · **US$36.251.931** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Saturn dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa dokumentasi sUSDat dan aset dasarnya, USDat. Telusuri satu permintaan penebusan asinkron, besaran saham dan kondisi penyelesaian. Saturn diwajibkan oleh watchlist resmi.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Telusuri contoh transaksi publik dari receipt ke aset dasar.
5. Catat antrean, kuantitas saham dan titik saat underlying benar-benar tersedia.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Saturn · yield-dollar contract documentation](https://github.com/saturn-organization/saturn-yield-dollar)

## 20. Galaxy Curation

**Watchlist resmi** · Risk Curators · Base · **US$35.720.943** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Galaxy Curation dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Gunakan direktori Galaxy dan pisahkan vault Morpho serta Kamino. Cocokkan jaringan, host, aset dan eksposur jaminan terbesar.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Galaxy · curation directory](https://curation.galaxy.com/)

## 21. Lightning Network

**Watchlist resmi** · Payments · Bitcoin · **US$31.687.895** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Lightning Network dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Baca invoice Lightning dari penggunaan nyata yang sudah ada. Cocokkan jumlah BTC, waktu kedaluwarsa, biaya routing dan status penyelesaian. Aktivitas ini dapat diteliti tanpa membuka channel baru.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Bandingkan detail invoice dengan receipt dari pembayaran yang telah selesai.
5. Catat status dan fee secara pribadi. Simpan preimage dan data pembayaran sensitif di luar laporan publik.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [ACINQ · Phoenix](https://github.com/ACINQ/phoenix)

## 22. Hive Protocol

**Watchlist resmi** · Chain · BSquared · **US$29.344.824** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Hive Protocol dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih Hive pada B² lewat listing DefiLlama yang benar. Pisahkan BTC yang dikunci, insentif B2 yang disebut di listing dan estimasi token hipotetis di radar.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Telusuri satu transaksi publik yang sungguh terjadi. Catat tindakan pengguna dan bukti settlement.
5. Cocokkan receipt dengan alamat atau perantara yang benar-benar mendapat kredit.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [DefiLlama · BSquared Hive record](https://defillama.com/protocol/hive-protocol)

## 23. Lofty

**Watchlist resmi** · RWA · Algorand · **US$28.679.751** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Lofty dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Baca satu listing properti serta syarat marketplace Lofty. Catat kepemilikan yang diwakili, penyelesaian dalam USDL, pembatasan akses, lalu lihat ukuran bid yang benar-benar tersedia.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Baca minimum, biaya, metode custody dan dokumen subscription. Catat apakah akses tersedia untuk situasimu.
5. Catat jadwal penebusan, aset settlement dan pihak lawan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Lofty · marketplace terms](https://www.lofty.ai/terms)

## 24. Armitage by Wintermute

**Watchlist resmi** · Risk Curators · Ethereum · **US$27.947.897** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Armitage by Wintermute dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Baca dokumentasi Armitage milik Wintermute. Di vault Morpho V2, cocokkan peran kurator dan allocator, aset dasar, serta batas eksposur.
3. Contoh maksimum pokok US$25 yang sudah ada di Ethereum. Batasi total fee masuk, approval, spread dan keluar hingga US$5. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Wintermute · Armitage documentation](https://armitage.wintermute.com/docs)

## 25. Valos

**Watchlist resmi** · RWA · Monad · **US$25.918.177** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Valos dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa struktur private credit di Monad. Untuk VUSD, catat penerbit, hak pemegang terhadap eksposur kredit dan syarat subscription atau redemption.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Baca minimum, biaya, metode custody dan dokumen subscription. Catat apakah akses tersedia untuk situasimu.
5. Catat jadwal penebusan, aset settlement dan pihak lawan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [DefiLlama · Valos private-credit record](https://defillama.com/protocol/valos)

## 26. Decibel

**Penemuan di bawah US$50 juta** · Derivatives · Aptos · **US$23.514.948** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Decibel dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar. Baca harga acuan, fee, funding atau waktu penyelesaian dan akses pengguna.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/decibel)

## 27. Apex Omni

**Penemuan di bawah US$50 juta** · Derivatives · Base · **US$23.366.715** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Apex Omni dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar. Baca harga acuan, fee, funding atau waktu penyelesaian dan akses pengguna.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/apex-omni)

## 28. Ember

**Watchlist resmi** · RWA · Sui · **US$23.311.304** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Ember dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih vault Ember dengan manajer dan strategi yang teridentifikasi. Periksa hubungan jumlah receipt token dengan bagian aset dan apa yang bisa ditebus.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Baca minimum, biaya, metode custody dan dokumen subscription. Catat apakah akses tersedia untuk situasimu.
5. Catat jadwal penebusan, aset settlement dan pihak lawan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Ember · core concepts](https://learn.ember.so/ember-protocol/core-concepts)

## 29. Doppler Finance

**Watchlist resmi** · CeDeFi · Ripple · **US$22.402.217** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Doppler Finance dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pelajari Doppler XRP Vault. Catat denominasi XRP, waktu penarikan yang tertulis, permintaan penarikan dan kapan aset benar-benar kembali di XRPL.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Baca minimum, biaya, metode custody dan dokumen subscription. Catat apakah akses tersedia untuk situasimu.
5. Catat jadwal penebusan, aset settlement dan pihak lawan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Doppler · XRP vault](https://docs.doppler.finance/product/doppler-vaults/xrp-vault)

## 30. Keyrock

**Watchlist resmi** · Risk Curators · Ethereum · **US$20.965.070** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Keyrock dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Gunakan listing kurator Keyrock untuk menemukan vault, lalu cocokkan chain dan kontraknya di Morpho. Periksa USDC yang tersedia serta alokasinya.
3. Contoh maksimum pokok US$25 yang sudah ada di Ethereum. Batasi total fee masuk, approval, spread dan keluar hingga US$5. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [MorphoWatch · Keyrock curator research](https://morphowatch.com/curators/keyrock/)

## 31. Curvance

**Watchlist resmi** · Lending · Monad · **US$19.499.455** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Curvance dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Di Monad, buka satu pasar Curvance. Baca aset supply, aset utang pasangannya, batas jaminan dan likuiditas. Pratinjau supply dengan utang tetap nol.
3. Contoh maksimum pokok US$25 yang sudah ada di Monad. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply dengan utang nol. Cocokkan nilai approval dan receipt serta aset yang akan dipindah.
5. Kuotasi penarikan ke aset awal dan periksa likuiditas pasar untuk menyelesaikannya.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Curvance · market accounting](https://app.curvance.com/transparency.html)

## 32. Predict Fun

**Penemuan di bawah US$50 juta** · Prediction Market · Binance · **US$17.912.536** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Predict Fun dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar. Baca harga acuan, fee, funding atau waktu penyelesaian dan akses pengguna.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/predict-fun)

## 33. Phoenix Perp

**Penemuan di bawah US$50 juta** · Derivatives · Solana · **US$17.781.761** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Phoenix Perp dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar. Baca harga acuan, fee, funding atau waktu penyelesaian dan akses pengguna.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/phoenix-perp)

## 34. Liminal Basis

**Penemuan di bawah US$50 juta** · Basis Trading · Hyperliquid L1 · **US$17.712.660** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Liminal Basis dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar. Baca harga acuan, fee, funding atau waktu penyelesaian dan akses pengguna.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/liminal-basis)

## 35. Gami Labs

**Watchlist resmi** · Risk Curators · Stellar · **US$17.173.149** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Gami Labs dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa mandat investasi Gami dan siapa yang boleh masuk ke produk terkait. Catat manajer, kendaraan investasi dan syarat akses sebelum tindakan apa pun.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Gami · investment mandate](https://gamilabs.io/about)

## 36. RISEx

**Penemuan di bawah US$50 juta** · Derivatives · RISE · **US$16.826.982** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi RISEx dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar. Baca harga acuan, fee, funding atau waktu penyelesaian dan akses pengguna.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/risex)

## 37. Drakewell

**Penemuan di bawah US$50 juta** · Basis Trading · Arbitrum · **US$16.157.174** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Drakewell dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar. Baca harga acuan, fee, funding atau waktu penyelesaian dan akses pengguna.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/drakewell)

## 38. Tydro

**Watchlist resmi** · Lending · Ink · **US$15.728.596** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Tydro dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Di Ink, buka satu cadangan Tydro. Baca supply cap, utilisasi dan likuiditas untuk penarikan. Rute yang diuji hanya sisi penyedia aset.
3. Contoh maksimum pokok US$25 yang sudah ada di Ink. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply dengan utang nol. Cocokkan nilai approval dan receipt serta aset yang akan dipindah.
5. Kuotasi penarikan ke aset awal dan periksa likuiditas pasar untuk menyelesaikannya.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Tydro · lending documentation](https://docs.tydro.com/)

## 39. b14g

**Watchlist resmi** · Restaking · Bitcoin · **US$14.780.282** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi b14g dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pisahkan BTC dari aset jaringan mitra pada rute dual staking. Catat aset yang dikunci, siapa yang mengendalikan tiap leg, syarat pembukaan dan risikonya.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Periksa kuotasi masuk dan modelkan dampak penalti terhadap saldo. Catat siapa yang berhak menarik.
5. Petakan urutan meminta penarikan, menunggu dan mengklaim beserta waktu paling awal yang didokumentasikan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [DefiLlama · b14g dual staking](https://defillama.com/protocol/b14g)

## 40. Project X

**Penemuan di bawah US$50 juta** · Dexs · Hyperliquid L1 · **US$14.584.889** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Project X dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih pasangan spot yang didokumentasikan dan cocokkan dua ID aset, cadangan serta fee.
3. Contoh maksimum pokok US$25 yang sudah ada di Hyperliquid L1. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Bandingkan kuotasi pada dua ukuran untuk swap yang memang dibutuhkan. Catat minimum diterima dan dampak harga.
5. Hitung biaya dan spread dari kuotasi arah balik sebelum masuk. Simpan receipt hanya bila transaksi dijalankan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/project-x)

## 41. Tulipa Capital

**Watchlist resmi** · Risk Curators · Base · **US$14.452.791** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Tulipa Capital dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Mulai dari uraian strategi Tulipa. Cocokkan hosting vault, peran kurator dan allocator, aset dasar serta jalur keluar di halaman produk.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Tulipa Capital · vault strategies](https://www.tulipa.capital/)

## 42. Lagoon

**Watchlist resmi** · Onchain Capital Allocator · Base · **US$14.266.517** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Lagoon dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Tentukan apakah vault Lagoon sinkron atau asinkron. Pisahkan permintaan deposit, perhitungan NAV, saham yang sudah settled dan aset yang bisa diklaim saat redeem.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Lagoon · deposit and withdrawal flows](https://docs.lagoon.finance/vault/deposit-and-withdraw-flows)

## 43. infiniFi

**Watchlist resmi** · Yield · Ethereum · **US$13.615.428** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi infiniFi dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Di Ethereum, bedakan iUSD, siUSD dan posisi yang dikunci. Kuotasi siUSD ke iUSD dan iUSD ke USDC secara terpisah. Catat jumlah likuiditas yang tersedia.
3. Contoh maksimum pokok US$25 yang sudah ada di Ethereum. Batasi total fee masuk, approval, spread dan keluar hingga US$5. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Yearn Curation · infiniFi research](https://curation.yearn.fi/report/infinifi/)

## 44. Re7 Labs

**Penemuan di bawah US$50 juta** · Risk Curators · Base · **US$12.700.367** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Re7 Labs dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/re7-labs)

## 45. Firelight

**Watchlist resmi** · Insurance · Flare · **US$11.774.563** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Firelight dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Di Flare, bedakan pokok FXRP dari saham stXRP. Catat fase dan kalender penarikan. Bandingkan unstake lalu claim dengan kuotasi jual di pasar sekunder.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Periksa kuotasi masuk dan modelkan dampak penalti terhadap saldo. Catat siapa yang berhak menarik.
5. Petakan urutan meminta penarikan, menunggu dan mengklaim beserta waktu paling awal yang didokumentasikan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Firelight · withdrawal guide](https://firelight.finance/articles/step-by-step-guide-to-withdrawing-and-unstaking-on-firelight-in-phase-1)

## 46. Noble

**Watchlist resmi** · Chain · Noble · **US$11.681.552** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Noble dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Telusuri satu transfer USDC yang pernah terjadi melalui Noble dan IBC. Cocokkan denom aset, chain asal, channel tujuan dan acknowledgement.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Telusuri satu transaksi publik yang sungguh terjadi. Catat tindakan pengguna dan bukti settlement.
5. Cocokkan receipt dengan alamat atau perantara yang benar-benar mendapat kredit.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Circle · USDC on Noble](https://help.circle.com/s/article/A-closer-look-at-Noble-USDC-and-the-IBC-protocol?category=Utilizing_USDC)

## 47. Yuzu Money

**Watchlist resmi** · Yield · Plasma · **US$10.517.605** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Yuzu Money dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Di Plasma, pisahkan yzUSD dan saham syzUSD. Periksa jalur redeem saham menjadi yzUSD dan jalur menerima aset penyelesaian.
3. Contoh maksimum pokok US$25 yang sudah ada di Plasma. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Yuzu Money · asset documentation](https://app.yuzu.money/docs)

## 48. Shift DeFi

**Penemuan di bawah US$50 juta** · Yield · Ethereum · **US$10.294.888** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Shift DeFi dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Ethereum. Batasi total fee masuk, approval, spread dan keluar hingga US$5. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/shift-defi)

## 49. Reya Perps

**Penemuan di bawah US$50 juta** · Derivatives · Reya Network · **US$8.496.789** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Reya Perps dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar. Baca harga acuan, fee, funding atau waktu penyelesaian dan akses pengguna.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/reya-perps)

## 50. Noon

**Penemuan di bawah US$50 juta** · Yield · Ethereum · **US$7.601.541** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Noon dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Ethereum. Batasi total fee masuk, approval, spread dan keluar hingga US$5. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/noon)

## 51. BisonFi

**Penemuan di bawah US$50 juta** · Dexs · Solana · **US$7.596.314** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi BisonFi dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih pasangan spot yang didokumentasikan dan cocokkan dua ID aset, cadangan serta fee.
3. Contoh maksimum pokok US$25 yang sudah ada di Solana. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Bandingkan kuotasi pada dua ukuran untuk swap yang memang dibutuhkan. Catat minimum diterima dan dampak harga.
5. Hitung biaya dan spread dari kuotasi arah balik sebelum masuk. Simpan receipt hanya bila transaksi dijalankan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/bisonfi)

## 52. Y10K Capital

**Penemuan di bawah US$50 juta** · Risk Curators · Monad · **US$7.283.286** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Y10K Capital dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Monad. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/y10k-capital)

## 53. BounceBit Prime

**Penemuan di bawah US$50 juta** · Basis Trading · Ethereum · **US$7.252.139** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi BounceBit Prime dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar. Baca harga acuan, fee, funding atau waktu penyelesaian dan akses pengguna.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/bouncebit-prime)

## 54. 3F

**Penemuan di bawah US$50 juta** · Leveraged Farming · Ethereum · **US$7.104.253** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi 3F dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar. Baca harga acuan, fee, funding atau waktu penyelesaian dan akses pengguna.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/3f)

## 55. Mezo Earn

**Watchlist resmi** · Governance Incentives · Mezo · **US$7.028.663** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Mezo Earn dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa satu vote gauge yang sudah selesai di Mezo. Bedakan penguncian, veBTC dan fee gauge. Catat epoch dan siapa yang sebenarnya berhak atas fee.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Telusuri satu transaksi publik yang sungguh terjadi. Catat tindakan pengguna dan bukti settlement.
5. Cocokkan receipt dengan alamat atau perantara yang benar-benar mendapat kredit.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Mezo · voting and incentives](https://mezo.org/docs/users/mezo-earn/vote/)

## 56. August Digital

**Penemuan di bawah US$50 juta** · Risk Curators · Monad · **US$6.923.626** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi August Digital dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Monad. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/august-digital)

## 57. Agni Finance

**Penemuan di bawah US$50 juta** · Dexs · Mantle · **US$6.773.419** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Agni Finance dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih pasangan spot yang didokumentasikan dan cocokkan dua ID aset, cadangan serta fee.
3. Contoh maksimum pokok US$25 yang sudah ada di Mantle. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Bandingkan kuotasi pada dua ukuran untuk swap yang memang dibutuhkan. Catat minimum diterima dan dampak harga.
5. Hitung biaya dan spread dari kuotasi arah balik sebelum masuk. Simpan receipt hanya bila transaksi dijalankan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/agni-finance)

## 58. Antarctic

**Penemuan di bawah US$50 juta** · Derivatives · Arbitrum · **US$6.753.097** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Antarctic dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar. Baca harga acuan, fee, funding atau waktu penyelesaian dan akses pengguna.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/antarctic)

## 59. Flux Finance

**Penemuan di bawah US$50 juta** · Lending · Ethereum · **US$6.753.002** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Flux Finance dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar supply. Catat aset, utilisasi, supply cap, likuiditas dan batas penarikan.
3. Contoh maksimum pokok US$25 yang sudah ada di Ethereum. Batasi total fee masuk, approval, spread dan keluar hingga US$5. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply dengan utang nol. Cocokkan nilai approval dan receipt serta aset yang akan dipindah.
5. Kuotasi penarikan ke aset awal dan periksa likuiditas pasar untuk menyelesaikannya.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/flux-finance)

## 60. Project 0

**Penemuan di bawah US$50 juta** · Lending · Solana · **US$6.686.992** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Project 0 dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar supply. Catat aset, utilisasi, supply cap, likuiditas dan batas penarikan.
3. Contoh maksimum pokok US$25 yang sudah ada di Solana. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply dengan utang nol. Cocokkan nilai approval dan receipt serta aset yang akan dipindah.
5. Kuotasi penarikan ke aset awal dan periksa likuiditas pasar untuk menyelesaikannya.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/project-0)

## 61. Current

**Penemuan di bawah US$50 juta** · Lending · Sui · **US$6.686.249** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Current dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar supply. Catat aset, utilisasi, supply cap, likuiditas dan batas penarikan.
3. Contoh maksimum pokok US$25 yang sudah ada di Sui. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply dengan utang nol. Cocokkan nilai approval dan receipt serta aset yang akan dipindah.
5. Kuotasi penarikan ke aset awal dan periksa likuiditas pasar untuk menyelesaikannya.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/current)

## 62. Arrakis Modular

**Penemuan di bawah US$50 juta** · Liquidity Manager · Base · **US$6.420.376** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Arrakis Modular dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih pasangan, fee tier dan kebijakan rentang harga dari satu posisi likuiditas.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Simulasikan kedua leg dan bandingkan saldo token awal dengan saham yang ditawarkan.
5. Kuotasi pengeluaran likuiditas dan catat komposisi dua aset bila harga keluar dari rentang.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/arrakis-modular)

## 63. Flowdesk

**Penemuan di bawah US$50 juta** · Risk Curators · Ethereum · **US$6.333.134** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Flowdesk dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Ethereum. Batasi total fee masuk, approval, spread dan keluar hingga US$5. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/flowdesk)

## 64. Anemoy Capital

**Penemuan di bawah US$50 juta** · RWA · Base · **US$6.015.217** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Anemoy Capital dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa penerbit, bentuk klaim, negara yang diizinkan dan syarat investor.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Baca minimum, biaya, metode custody dan dokumen subscription. Catat apakah akses tersedia untuk situasimu.
5. Catat jadwal penebusan, aset settlement dan pihak lawan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/anemoy-capital)

## 65. Gamma Research

**Penemuan di bawah US$50 juta** · Risk Curators · Monad · **US$5.870.883** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Gamma Research dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Monad. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/gamma-research)

## 66. BULK

**Penemuan di bawah US$50 juta** · Derivatives · Solana · **US$5.829.966** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi BULK dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar. Baca harga acuan, fee, funding atau waktu penyelesaian dan akses pengguna.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/bulk)

## 67. Waterline

**Penemuan di bawah US$50 juta** · Risk Curators · Ethereum · **US$5.810.950** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Waterline dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Ethereum. Batasi total fee masuk, approval, spread dan keluar hingga US$5. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/waterline)

## 68. TurboFlow Perps

**Penemuan di bawah US$50 juta** · Derivatives · Solana · **US$5.466.133** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi TurboFlow Perps dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar. Baca harga acuan, fee, funding atau waktu penyelesaian dan akses pengguna.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/turboflow-perps)

## 69. FstSwap

**Penemuan di bawah US$50 juta** · Dexs · Binance · **US$5.204.353** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi FstSwap dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih pasangan spot yang didokumentasikan dan cocokkan dua ID aset, cadangan serta fee.
3. Contoh maksimum pokok US$25 yang sudah ada di Binance. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Bandingkan kuotasi pada dua ukuran untuk swap yang memang dibutuhkan. Catat minimum diterima dan dampak harga.
5. Hitung biaya dan spread dari kuotasi arah balik sebelum masuk. Simpan receipt hanya bila transaksi dijalankan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/fstswap)

## 70. HertzFlow

**Penemuan di bawah US$50 juta** · Derivatives · Binance · **US$5.200.944** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi HertzFlow dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar. Baca harga acuan, fee, funding atau waktu penyelesaian dan akses pengguna.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/hertzflow)

## 71. Origami Finance

**Penemuan di bawah US$50 juta** · Leveraged Farming · Ethereum · **US$5.083.931** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Origami Finance dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar. Baca harga acuan, fee, funding atau waktu penyelesaian dan akses pengguna.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/origami-finance)

## 72. NEMO Trading

**Penemuan di bawah US$50 juta** · Risk Curators · Ethereum · **US$5.014.509** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi NEMO Trading dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Ethereum. Batasi total fee masuk, approval, spread dan keluar hingga US$5. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/nemo-trading)

## 73. Manifest Trade

**Penemuan di bawah US$50 juta** · Dexs · Solana · **US$4.860.596** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Manifest Trade dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih pasangan spot yang didokumentasikan dan cocokkan dua ID aset, cadangan serta fee.
3. Contoh maksimum pokok US$25 yang sudah ada di Solana. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Bandingkan kuotasi pada dua ukuran untuk swap yang memang dibutuhkan. Catat minimum diterima dan dampak harga.
5. Hitung biaya dan spread dari kuotasi arah balik sebelum masuk. Simpan receipt hanya bila transaksi dijalankan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/manifest-trade)

## 74. Hakutora

**Penemuan di bawah US$50 juta** · Risk Curators · Ethereum · **US$4.665.227** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Hakutora dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Ethereum. Batasi total fee masuk, approval, spread dan keluar hingga US$5. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/hakutora)

## 75. Zoo Finance

**Penemuan di bawah US$50 juta** · Yield · Base · **US$4.613.032** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Zoo Finance dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/zoo-finance)

## 76. 9Summits

**Penemuan di bawah US$50 juta** · Risk Curators · Base · **US$4.447.612** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi 9Summits dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/9summits)

## 77. Mystic Finance Lending

**Penemuan di bawah US$50 juta** · Lending · Flare · **US$4.398.559** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Mystic Finance Lending dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar supply. Catat aset, utilisasi, supply cap, likuiditas dan batas penarikan.
3. Contoh maksimum pokok US$25 yang sudah ada di Flare. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply dengan utang nol. Cocokkan nilai approval dan receipt serta aset yang akan dipindah.
5. Kuotasi penarikan ke aset awal dan periksa likuiditas pasar untuk menyelesaikannya.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/mystic-finance-lending)

## 78. vfat.io

**Penemuan di bawah US$50 juta** · Yield Aggregator · Base · **US$4.391.838** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi vfat.io dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/vfat.io)

## 79. Tessera V

**Penemuan di bawah US$50 juta** · Dexs · Solana · **US$4.208.844** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Tessera V dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih pasangan spot yang didokumentasikan dan cocokkan dua ID aset, cadangan serta fee.
3. Contoh maksimum pokok US$25 yang sudah ada di Solana. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Bandingkan kuotasi pada dua ukuran untuk swap yang memang dibutuhkan. Catat minimum diterima dan dampak harga.
5. Hitung biaya dan spread dari kuotasi arah balik sebelum masuk. Simpan receipt hanya bila transaksi dijalankan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/tessera-v)

## 80. marginfi Lending

**Penemuan di bawah US$50 juta** · Lending · Solana · **US$4.104.183** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi marginfi Lending dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar supply. Catat aset, utilisasi, supply cap, likuiditas dan batas penarikan.
3. Contoh maksimum pokok US$25 yang sudah ada di Solana. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply dengan utang nol. Cocokkan nilai approval dan receipt serta aset yang akan dipindah.
5. Kuotasi penarikan ke aset awal dan periksa likuiditas pasar untuk menyelesaikannya.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/marginfi-lending)

## 81. Boros

**Penemuan di bawah US$50 juta** · Interest Rate Derivatives · Arbitrum · **US$4.078.341** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Boros dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar. Baca harga acuan, fee, funding atau waktu penyelesaian dan akses pengguna.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, hitung dampak pergerakan harga 5% berlawanan dengan posisi. Simpan spread serta funding jika ada.
5. Kuotasi keluar dengan ukuran yang sama dan simpan dua kuotasi beserta waktu pengamatan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/boros)

## 82. Lulo

**Penemuan di bawah US$50 juta** · Yield Aggregator · Solana · **US$3.887.881** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Lulo dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Solana. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/lulo)

## 83. Templar Lending

**Penemuan di bawah US$50 juta** · Lending · Solana · **US$3.882.670** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Templar Lending dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar supply. Catat aset, utilisasi, supply cap, likuiditas dan batas penarikan.
3. Contoh maksimum pokok US$25 yang sudah ada di Solana. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply dengan utang nol. Cocokkan nilai approval dan receipt serta aset yang akan dipindah.
5. Kuotasi penarikan ke aset awal dan periksa likuiditas pasar untuk menyelesaikannya.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/templar-lending)

## 84. Estate Protocol

**Penemuan di bawah US$50 juta** · RWA · Arbitrum · **US$3.851.668** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Estate Protocol dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa penerbit, bentuk klaim, negara yang diizinkan dan syarat investor.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Baca minimum, biaya, metode custody dan dokumen subscription. Catat apakah akses tersedia untuk situasimu.
5. Catat jadwal penebusan, aset settlement dan pihak lawan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/estate-protocol)

## 85. Hylo Protocol

**Penemuan di bawah US$50 juta** · Dual-Token Stablecoin · Solana · **US$3.814.064** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Hylo Protocol dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Baca collateral yang diterima, oracle, batas mint dan aturan likuidasi.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, ubah harga jaminan dan jumlah utang untuk melihat kapan buffer habis.
5. Kalkulasikan biaya pelunasan dan pembukaan collateral serta kondisi peg.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/hylo-protocol)

## 86. Byreal

**Penemuan di bawah US$50 juta** · Dexs · Solana · **US$3.716.255** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Byreal dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih pasangan spot yang didokumentasikan dan cocokkan dua ID aset, cadangan serta fee.
3. Contoh maksimum pokok US$25 yang sudah ada di Solana. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Bandingkan kuotasi pada dua ukuran untuk swap yang memang dibutuhkan. Catat minimum diterima dan dampak harga.
5. Hitung biaya dan spread dari kuotasi arah balik sebelum masuk. Simpan receipt hanya bila transaksi dijalankan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/byreal)

## 87. Paimon

**Penemuan di bawah US$50 juta** · RWA · Binance · **US$3.617.967** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Paimon dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa penerbit, bentuk klaim, negara yang diizinkan dan syarat investor.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Baca minimum, biaya, metode custody dan dokumen subscription. Catat apakah akses tersedia untuk situasimu.
5. Catat jadwal penebusan, aset settlement dan pihak lawan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/paimon)

## 88. NUVA

**Penemuan di bawah US$50 juta** · Yield · Ethereum · **US$3.592.982** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi NUVA dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Ethereum. Batasi total fee masuk, approval, spread dan keluar hingga US$5. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/nuva)

## 89. Syntetika

**Penemuan di bawah US$50 juta** · Risk Curators · Base · **US$3.590.347** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Syntetika dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/syntetika)

## 90. Makina

**Penemuan di bawah US$50 juta** · Onchain Capital Allocator · Base · **US$3.534.551** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Makina dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/makina)

## 91. MetalX Swap

**Penemuan di bawah US$50 juta** · Dexs · Proton · **US$3.320.828** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi MetalX Swap dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih pasangan spot yang didokumentasikan dan cocokkan dua ID aset, cadangan serta fee.
3. Contoh maksimum pokok US$25 yang sudah ada di Proton. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Bandingkan kuotasi pada dua ukuran untuk swap yang memang dibutuhkan. Catat minimum diterima dan dampak harga.
5. Hitung biaya dan spread dari kuotasi arah balik sebelum masuk. Simpan receipt hanya bila transaksi dijalankan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/metalx-swap)

## 92. Goose

**Penemuan di bawah US$50 juta** · CeDeFi · Arbitrum · **US$3.277.689** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Goose dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa penerbit, bentuk klaim, negara yang diizinkan dan syarat investor.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Baca minimum, biaya, metode custody dan dokumen subscription. Catat apakah akses tersedia untuk situasimu.
5. Catat jadwal penebusan, aset settlement dan pihak lawan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/goose)

## 93. RockSolid Network

**Penemuan di bawah US$50 juta** · Yield · Ethereum · **US$3.265.193** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi RockSolid Network dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Ethereum. Batasi total fee masuk, approval, spread dan keluar hingga US$5. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/rocksolid-network)

## 94. SyncSwap

**Penemuan di bawah US$50 juta** · Dexs · zkSync Era · **US$3.202.054** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi SyncSwap dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih pasangan spot yang didokumentasikan dan cocokkan dua ID aset, cadangan serta fee.
3. Contoh maksimum pokok US$25 yang sudah ada di zkSync Era. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Bandingkan kuotasi pada dua ukuran untuk swap yang memang dibutuhkan. Catat minimum diterima dan dampak harga.
5. Hitung biaya dan spread dari kuotasi arah balik sebelum masuk. Simpan receipt hanya bila transaksi dijalankan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/syncswap)

## 95. XION Finance

**Penemuan di bawah US$50 juta** · Chain · XION · **US$3.182.337** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi XION Finance dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa chain, unit biaya dan aturan penggunaan yang diterbitkan proyek.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Telusuri satu transaksi publik yang sungguh terjadi. Catat tindakan pengguna dan bukti settlement.
5. Cocokkan receipt dengan alamat atau perantara yang benar-benar mendapat kredit.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/xion-finance)

## 96. Icarus CL

**Penemuan di bawah US$50 juta** · Dexs · RISE · **US$3.088.846** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Icarus CL dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih pasangan spot yang didokumentasikan dan cocokkan dua ID aset, cadangan serta fee.
3. Contoh maksimum pokok US$25 yang sudah ada di RISE. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Bandingkan kuotasi pada dua ukuran untuk swap yang memang dibutuhkan. Catat minimum diterima dan dampak harga.
5. Hitung biaya dan spread dari kuotasi arah balik sebelum masuk. Simpan receipt hanya bila transaksi dijalankan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/icarus-cl)

## 97. Fluxion Network

**Penemuan di bawah US$50 juta** · Dexs · Mantle · **US$2.983.171** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Fluxion Network dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih pasangan spot yang didokumentasikan dan cocokkan dua ID aset, cadangan serta fee.
3. Contoh maksimum pokok US$25 yang sudah ada di Mantle. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Bandingkan kuotasi pada dua ukuran untuk swap yang memang dibutuhkan. Catat minimum diterima dan dampak harga.
5. Hitung biaya dan spread dari kuotasi arah balik sebelum masuk. Simpan receipt hanya bila transaksi dijalankan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/fluxion-network)

## 98. Fira

**Penemuan di bawah US$50 juta** · Lending · Ethereum · **US$2.927.349** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Fira dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar supply. Catat aset, utilisasi, supply cap, likuiditas dan batas penarikan.
3. Contoh maksimum pokok US$25 yang sudah ada di Ethereum. Batasi total fee masuk, approval, spread dan keluar hingga US$5. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply dengan utang nol. Cocokkan nilai approval dan receipt serta aset yang akan dipindah.
5. Kuotasi penarikan ke aset awal dan periksa likuiditas pasar untuk menyelesaikannya.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/fira)

## 99. Reti Pooling

**Watchlist resmi** · Staking Pool · Algorand · **US$2.918.756** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Reti Pooling dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih validator Réti di Algorand. Catat minimum masuk, komisi, frekuensi distribusi, syarat bergabung dan aturan keluar dari staking pool.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Periksa kuotasi masuk dan modelkan dampak penalti terhadap saldo. Catat siapa yang berhak menarik.
5. Petakan urutan meminta penarikan, menunggu dan mengklaim beserta waktu paling awal yang didokumentasikan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Rujukan produk spesifik. [Réti · validator configuration](https://txnlab.gitbook.io/reti-open-pooling/getting-started/quick-start-for-validators)

## 100. Native Credit Pool

**Penemuan di bawah US$50 juta** · Lending · Base · **US$2.840.631** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Native Credit Pool dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar supply. Catat aset, utilisasi, supply cap, likuiditas dan batas penarikan.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply dengan utang nol. Cocokkan nilai approval dan receipt serta aset yang akan dipindah.
5. Kuotasi penarikan ke aset awal dan periksa likuiditas pasar untuk menyelesaikannya.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/native-credit-pool)

## 101. TAU Labs

**Penemuan di bawah US$50 juta** · Risk Curators · Base · **US$2.802.831** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi TAU Labs dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/tau-labs)

## 102. Strata Markets

**Penemuan di bawah US$50 juta** · Yield · Ethereum · **US$2.800.023** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Strata Markets dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Ethereum. Batasi total fee masuk, approval, spread dan keluar hingga US$5. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/strata-markets)

## 103. DeFindex

**Penemuan di bawah US$50 juta** · Yield Aggregator · Stellar · **US$2.755.331** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi DeFindex dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Stellar. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/defindex)

## 104. Hyperbeat Earn

**Penemuan di bawah US$50 juta** · Yield Aggregator · Hyperliquid L1 · **US$2.723.601** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Hyperbeat Earn dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Hyperliquid L1. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/hyperbeat-earn)

## 105. 3Jane Lending

**Penemuan di bawah US$50 juta** · Uncollateralized Lending · Ethereum · **US$2.675.691** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi 3Jane Lending dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa penerbit, bentuk klaim, negara yang diizinkan dan syarat investor.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Baca minimum, biaya, metode custody dan dokumen subscription. Catat apakah akses tersedia untuk situasimu.
5. Catat jadwal penebusan, aset settlement dan pihak lawan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/3jane-lending)

## 106. SharpByte Capital

**Penemuan di bawah US$50 juta** · Risk Curators · Monad · **US$2.613.615** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi SharpByte Capital dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Monad. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/sharpbyte-capital)

## 107. Binaryx Platform

**Penemuan di bawah US$50 juta** · RWA · Polygon · **US$2.536.370** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Binaryx Platform dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa penerbit, bentuk klaim, negara yang diizinkan dan syarat investor.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Baca minimum, biaya, metode custody dan dokumen subscription. Catat apakah akses tersedia untuk situasimu.
5. Catat jadwal penebusan, aset settlement dan pihak lawan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/binaryx-platform)

## 108. GrowiHF

**Penemuan di bawah US$50 juta** · Yield · Hyperliquid L1 · **US$2.530.598** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi GrowiHF dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Hyperliquid L1. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/growihf)

## 109. Temple

**Penemuan di bawah US$50 juta** · Dexs · Canton · **US$2.391.065** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Temple dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih pasangan spot yang didokumentasikan dan cocokkan dua ID aset, cadangan serta fee.
3. Contoh maksimum pokok US$25 yang sudah ada di Canton. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Bandingkan kuotasi pada dua ukuran untuk swap yang memang dibutuhkan. Catat minimum diterima dan dampak harga.
5. Hitung biaya dan spread dari kuotasi arah balik sebelum masuk. Simpan receipt hanya bila transaksi dijalankan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/temple)

## 110. RIF ON CHAIN

**Penemuan di bawah US$50 juta** · Dual-Token Stablecoin · RSK · **US$2.360.799** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi RIF ON CHAIN dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Baca collateral yang diterima, oracle, batas mint dan aturan likuidasi.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, ubah harga jaminan dan jumlah utang untuk melihat kapan buffer habis.
5. Kalkulasikan biaya pelunasan dan pembukaan collateral serta kondisi peg.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/rif-on-chain)

## 111. Bucket CDP

**Penemuan di bawah US$50 juta** · CDP · Sui · **US$2.287.103** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Bucket CDP dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Baca collateral yang diterima, oracle, batas mint dan aturan likuidasi.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, ubah harga jaminan dan jumlah utang untuk melihat kapan buffer habis.
5. Kalkulasikan biaya pelunasan dan pembukaan collateral serta kondisi peg.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/bucket-cdp)

## 112. MEV Capital

**Penemuan di bawah US$50 juta** · Risk Curators · Base · **US$2.274.610** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi MEV Capital dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/mev-capital)

## 113. D2 Finance

**Penemuan di bawah US$50 juta** · Onchain Capital Allocator · Base · **US$2.160.438** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi D2 Finance dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/d2-finance)

## 114. Block Analitica

**Penemuan di bawah US$50 juta** · Risk Curators · Base · **US$2.127.826** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Block Analitica dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/block-analitica)

## 115. Syntropia

**Penemuan di bawah US$50 juta** · Yield Aggregator · Ethereum · **US$2.084.901** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Syntropia dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Ethereum. Batasi total fee masuk, approval, spread dan keluar hingga US$5. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/syntropia)

## 116. Pangolins

**Penemuan di bawah US$50 juta** · Risk Curators · Base · **US$2.044.953** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Pangolins dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/pangolins)

## 117. Neutral Trade

**Penemuan di bawah US$50 juta** · Onchain Capital Allocator · Solana · **US$2.009.402** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Neutral Trade dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Solana. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/neutral-trade)

## 118. GoonFi

**Penemuan di bawah US$50 juta** · Dexs · Solana · **US$1.985.933** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi GoonFi dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih pasangan spot yang didokumentasikan dan cocokkan dua ID aset, cadangan serta fee.
3. Contoh maksimum pokok US$25 yang sudah ada di Solana. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Bandingkan kuotasi pada dua ukuran untuk swap yang memang dibutuhkan. Catat minimum diterima dan dampak harga.
5. Hitung biaya dan spread dari kuotasi arah balik sebelum masuk. Simpan receipt hanya bila transaksi dijalankan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/goonfi)

## 119. STRATO CDP

**Penemuan di bawah US$50 juta** · CDP · Strato · **US$1.933.621** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi STRATO CDP dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Baca collateral yang diterima, oracle, batas mint dan aturan likuidasi.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, ubah harga jaminan dan jumlah utang untuk melihat kapan buffer habis.
5. Kalkulasikan biaya pelunasan dan pembukaan collateral serta kondisi peg.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/strato-cdp)

## 120. Steer Protocol

**Penemuan di bawah US$50 juta** · Liquidity Manager · Base · **US$1.886.185** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Steer Protocol dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih pasangan, fee tier dan kebijakan rentang harga dari satu posisi likuiditas.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Simulasikan kedua leg dan bandingkan saldo token awal dengan saham yang ditawarkan.
5. Kuotasi pengeluaran likuiditas dan catat komposisi dua aset bila harga keluar dari rentang.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/steer-protocol)

## 121. Anthias Labs

**Penemuan di bawah US$50 juta** · Risk Curators · Base · **US$1.883.899** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Anthias Labs dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/anthias-labs)

## 122. SuperEarn

**Penemuan di bawah US$50 juta** · Yield · Klaytn · **US$1.867.987** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi SuperEarn dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Klaytn. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/superearn)

## 123. Defa By InvoiceMate

**Penemuan di bawah US$50 juta** · RWA · Stellar · **US$1.840.773** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Defa By InvoiceMate dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa penerbit, bentuk klaim, negara yang diizinkan dan syarat investor.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Baca minimum, biaya, metode custody dan dokumen subscription. Catat apakah akses tersedia untuk situasimu.
5. Catat jadwal penebusan, aset settlement dan pihak lawan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/defa-by-invoicemate)

## 124. Vault Street

**Penemuan di bawah US$50 juta** · RWA · Ethereum · **US$1.713.235** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Vault Street dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa penerbit, bentuk klaim, negara yang diizinkan dan syarat investor.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Baca minimum, biaya, metode custody dan dokumen subscription. Catat apakah akses tersedia untuk situasimu.
5. Catat jadwal penebusan, aset settlement dan pihak lawan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/vault-street)

## 125. YieldFi

**Penemuan di bawah US$50 juta** · Yield Aggregator · Base · **US$1.694.795** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi YieldFi dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/yieldfi)

## 126. Agua

**Penemuan di bawah US$50 juta** · Onchain Capital Allocator · Monad · **US$1.674.527** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Agua dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Monad. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/agua)

## 127. BIMA CDP

**Penemuan di bawah US$50 juta** · CDP · Ethereum · **US$1.666.598** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi BIMA CDP dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Baca collateral yang diterima, oracle, batas mint dan aturan likuidasi.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, ubah harga jaminan dan jumlah utang untuk melihat kapan buffer habis.
5. Kalkulasikan biaya pelunasan dan pembukaan collateral serta kondisi peg.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/bima-cdp)

## 128. Set Protocol

**Penemuan di bawah US$50 juta** · Indexes · Ethereum · **US$1.665.839** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Set Protocol dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari dokumentasi produk dan periksa akses pada jaringan yang disebut.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Telusuri contoh tindakan pengguna melalui explorer dan catat parameter serta unitnya.
5. Tentukan cara posisi ditutup dan siapa yang menyelesaikan transaksi.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/set-protocol)

## 129. alphagrowth

**Penemuan di bawah US$50 juta** · Risk Curators · Base · **US$1.568.342** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi alphagrowth dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Base. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/alphagrowth)

## 130. Perena Vaults

**Penemuan di bawah US$50 juta** · Onchain Capital Allocator · Solana · **US$1.549.848** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Perena Vaults dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Solana. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/perena-vaults)

## 131. Monolith Market

**Penemuan di bawah US$50 juta** · CDP · Ethereum · **US$1.502.666** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Monolith Market dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Baca collateral yang diterima, oracle, batas mint dan aturan likuidasi.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, ubah harga jaminan dan jumlah utang untuk melihat kapan buffer habis.
5. Kalkulasikan biaya pelunasan dan pembukaan collateral serta kondisi peg.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/monolith-market)

## 132. DAMM Capital

**Penemuan di bawah US$50 juta** · Risk Curators · Arbitrum · **US$1.407.971** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi DAMM Capital dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Arbitrum. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/damm-capital)

## 133. Snuggle

**Penemuan di bawah US$50 juta** · Liquidity Manager · Base · **US$1.352.471** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Snuggle dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih pasangan, fee tier dan kebijakan rentang harga dari satu posisi likuiditas.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Simulasikan kedua leg dan bandingkan saldo token awal dengan saham yang ditawarkan.
5. Kuotasi pengeluaran likuiditas dan catat komposisi dua aset bila harga keluar dari rentang.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/snuggle)

## 134. Vesu

**Penemuan di bawah US$50 juta** · Lending · Starknet · **US$1.303.584** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Vesu dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar supply. Catat aset, utilisasi, supply cap, likuiditas dan batas penarikan.
3. Contoh maksimum pokok US$25 yang sudah ada di Starknet. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply dengan utang nol. Cocokkan nilai approval dan receipt serta aset yang akan dipindah.
5. Kuotasi penarikan ke aset awal dan periksa likuiditas pasar untuk menyelesaikannya.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/vesu)

## 135. BEND

**Penemuan di bawah US$50 juta** · Lending · Berachain · **US$1.272.679** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi BEND dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar supply. Catat aset, utilisasi, supply cap, likuiditas dan batas penarikan.
3. Contoh maksimum pokok US$25 yang sudah ada di Berachain. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply dengan utang nol. Cocokkan nilai approval dan receipt serta aset yang akan dipindah.
5. Kuotasi penarikan ke aset awal dan periksa likuiditas pasar untuk menyelesaikannya.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/bend)

## 136. Abstract

**Penemuan di bawah US$50 juta** · Chain · Ethereum · **US$1.264.995** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Abstract dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Periksa chain, unit biaya dan aturan penggunaan yang diterbitkan proyek.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Telusuri satu transaksi publik yang sungguh terjadi. Catat tindakan pengguna dan bukti settlement.
5. Cocokkan receipt dengan alamat atau perantara yang benar-benar mendapat kredit.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/abstract)

## 137. Vena Finance

**Penemuan di bawah US$50 juta** · Lending · Fluent · **US$1.260.331** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Vena Finance dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar supply. Catat aset, utilisasi, supply cap, likuiditas dan batas penarikan.
3. Contoh maksimum pokok US$25 yang sudah ada di Fluent. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply dengan utang nol. Cocokkan nilai approval dan receipt serta aset yang akan dipindah.
5. Kuotasi penarikan ke aset awal dan periksa likuiditas pasar untuk menyelesaikannya.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/vena-finance)

## 138. StableHodl

**Penemuan di bawah US$50 juta** · Yield · Ethereum · **US$1.234.204** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi StableHodl dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Ethereum. Batasi total fee masuk, approval, spread dan keluar hingga US$5. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/stablehodl)

## 139. T3tris Finance

**Penemuan di bawah US$50 juta** · Onchain Capital Allocator · Arbitrum · **US$1.217.808** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi T3tris Finance dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Arbitrum. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/t3tris-finance)

## 140. Monarq

**Penemuan di bawah US$50 juta** · Risk Curators · Flare · **US$1.203.875** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Monarq dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari vault yang secara eksplisit menyebut proyek sebagai kurator. Catat host, aset, alamat pool dan konsentrasi jaminan.
3. Contoh maksimum pokok US$25 yang sudah ada di Flare. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply satu aset. Simpan jumlah saham yang ditawarkan, identitas kurator, dan saldo underlying yang tersedia.
5. Kuotasi redeem saham ke aset dasar. Catat antrean, biaya dan likuiditas yang tersisa.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/monarq)

## 141. BTCFi CDP

**Penemuan di bawah US$50 juta** · CDP · Base · **US$1.068.968** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi BTCFi CDP dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Baca collateral yang diterima, oracle, batas mint dan aturan likuidasi.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, ubah harga jaminan dan jumlah utang untuk melihat kapan buffer habis.
5. Kalkulasikan biaya pelunasan dan pembukaan collateral serta kondisi peg.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/btcfi-cdp)

## 142. Mezzanine

**Penemuan di bawah US$50 juta** · Yield · Solana · **US$1.031.295** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Mezzanine dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Solana. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/mezzanine)

## 143. Adrastea Validator

**Penemuan di bawah US$50 juta** · Staking Pool · Solana · **US$934.995** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Adrastea Validator dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pool. Catat underlying, minimum, operator, periode unbonding dan penalti.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Periksa kuotasi masuk dan modelkan dampak penalti terhadap saldo. Catat siapa yang berhak menarik.
5. Petakan urutan meminta penarikan, menunggu dan mengklaim beserta waktu paling awal yang didokumentasikan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/adrastea-validator)

## 144. Swan DAO

**Penemuan di bawah US$50 juta** · CDP · Ethereum · **US$910.053** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Swan DAO dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Baca collateral yang diterima, oracle, batas mint dan aturan likuidasi.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Di kertas, ubah harga jaminan dan jumlah utang untuk melihat kapan buffer habis.
5. Kalkulasikan biaya pelunasan dan pembukaan collateral serta kondisi peg.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/swan-dao)

## 145. Granite

**Penemuan di bawah US$50 juta** · Lending · Stacks · **US$894.079** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Granite dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pasar supply. Catat aset, utilisasi, supply cap, likuiditas dan batas penarikan.
3. Contoh maksimum pokok US$25 yang sudah ada di Stacks. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau supply dengan utang nol. Cocokkan nilai approval dan receipt serta aset yang akan dipindah.
5. Kuotasi penarikan ke aset awal dan periksa likuiditas pasar untuk menyelesaikannya.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/granite)

## 146. Nucleus

**Penemuan di bawah US$50 juta** · Yield Aggregator · Arbitrum · **US$726.621** kapitalisasi tersirat. Rute uji kecil opsional.

1. Temukan dokumentasi resmi Nucleus dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Cari satu vault resmi. Identifikasi manajer, underlying, satuan saham serta mekanisme penebusan.
3. Contoh maksimum pokok US$25 yang sudah ada di Arbitrum. Batasi total fee masuk, approval, spread dan keluar hingga US$2. Siapkan sekitar 25 menit aktif. Jika minimum atau kuotasi melampaui batas, cukup catat pratinjaunya.
4. Pratinjau deposit satu aset dan bandingkan saham yang diterima dengan biaya serta minimum masuk.
5. Pratinjau penebusan ke underlying. Jika memakai antrean, catat permintaan, settlement dan kapan hasil bisa diambil.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/nucleus)

## 147. Qearn

**Penemuan di bawah US$50 juta** · Staking Pool · Qubic · **US$492.658** kapitalisasi tersirat. Rute observasi.

1. Temukan dokumentasi resmi Qearn dari listing yang sesuai. Verifikasi bahwa produk, chain dan aksesnya cocok sebelum memakai dompet.
2. Pilih satu pool. Catat underlying, minimum, operator, periode unbonding dan penalti.
3. Anggaran pokok dan biaya US$0. Luangkan sekitar 15 menit dan pelajari alurnya tanpa tanda tangan.
4. Periksa kuotasi masuk dan modelkan dampak penalti terhadap saldo. Catat siapa yang berhak menarik.
5. Petakan urutan meminta penarikan, menunggu dan mengklaim beserta waktu paling awal yang didokumentasikan.
6. Tinjau lagi setelah tujuh hari atau saat periode unlock yang dipublikasikan sudah terpenuhi. Bila ada pengumuman resmi, cocokkan aturan eligibilitas dengan alamat, tindakan, tanggal dan bukti milikmu.

Checklist kategori dan tautan direktori. [DefiLlama · protocol directory](https://defillama.com/protocol/qearn)

