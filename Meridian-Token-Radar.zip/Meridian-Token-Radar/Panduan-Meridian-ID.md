# Meridian — panduan dashboard dan submission

**Paket kode selesai. Pendaftaran bounty masih tertahan pada transkrip asli sesi pembuat kode.** Uji lokal terhadap tujuh syarat file berhasil, dua build Node 22 identik, dan CLI make.fun mengakui commit pertama dibuat setelah kompetisi dibuka. Perintah resmi `check` mengembalikan satu kegagalan, `transcripts_present`. Pemeriksaan yang bergantung pada isi transkrip belum dapat berjalan. Belum ada tanda tangan wallet, pengiriman entry, atau pemakaian kuota submission.

## Buka dalam satu klik

Buka **Meridian-Radar.html** setelah diunduh. File itu memuat data, CSS dan JavaScript sekaligus dan dapat dipakai saat perangkat offline. Versi yang dikirim ke grader memakai **meridian-radar/dashboard/index.html**. Untuk versi tersebut, ekstrak folder sumber secara utuh dan pertahankan **data.js** di direktori induk dashboard.

| File atau folder dalam ZIP | Isi |
| --- | --- |
| Meridian-Source.bundle | Git bundle v2 dengan seluruh histori dan branch submission |
| Meridian-Radar.html | Dashboard mandiri untuk langsung dibuka di browser |
| meridian-radar/ | Isi commit final yang bisa dibaca atau dijalankan langsung |
| meridian-radar/main.ts | Entry point Node 22.18, tanpa instalasi modul npm |
| meridian-radar/board.json | 147 kandidat, estimasi USD, data peer, cohort dan 882 langkah farm |
| meridian-radar/dashboard/ dan data.js di akar proyek | Versi statis untuk grader |
| meridian-radar/screenshots/ | Tiga PNG hasil capture browser. Papan utama, profil Steakhouse, serta hasil filter Lending dan Below floor |
| meridian-radar/dossier.json | Dossier kanonik yang dibangun vendor. Memuat ketiga screenshot dan seluruh kode dashboard |
| meridian-radar/data/snapshot.json | Snapshot asli, byte-identik dengan input kit |
| meridian-radar/vendor/ | Library dossier asli serta pemberitahuan lisensi |
| meridian-radar/RESEARCH.md | Sumber web, dokumentasi proyek, Telegram, forum dan metodologi |
| Rencana-Farm-ID.md | Enam langkah berbahasa Indonesia untuk setiap kandidat, dari peringkat 1 sampai 147 |
| kit/ | Kit pengembangan resmi yang digunakan, termasuk CLI, aturan dan starter penyelenggara |
| bukti/ | Hasil pemeriksaan, keluaran anchor, serta jurnal perubahan source yang direkam saat pengerjaan |

## Cara membaca ranking

Snapshot DefiLlama diambil 14 November 2026 pukul 08.18 WIB. Kit memuat 758 protokol dengan TVL setidaknya US$5 juta. Watchlist resmi memakai lantai US$50 juta dan pemeriksaan parent milik penyelenggara.

| Hasil seleksi | Jumlah | Cara memperlakukannya |
| --- | ---: | --- |
| Watchlist resmi | 40 | Semua masuk ranking |
| Kandidat tambahan di bawah ambang | 107 | Kedua kolom token kosong dan identitas lolos pemeriksaan konservatif |
| Punya identifier token | 416 | Masuk audit. Ada 128 dengan market cap positif dan 288 tanpa angka positif |
| Disisihkan oleh pemeriksaan identitas | 195 | Tetap dapat dibuka beserta alasan utama |
| Total | 758 | Setiap identitas tercatat satu kali |

Program memeriksa simbol dan ID CoinGecko. Produk wrapped, staked, bridge dan kustodi, deployment versi lain, nama aset serta keluarga produk yang terindikasi memiliki token dipisahkan. Contohnya GMX Solana cocok dengan identitas GMX pada deployment EVM. Sebanyak 18 entri di atas ambang yang tidak terpilih dalam daftar resmi juga ditahan. Data ekspor hanya memiliki sepuluh field, sehingga hubungan parent kandidat tambahan perlu diverifikasi sendiri.

Urutan mengikuti **estimasi kapitalisasi pasar beredar apabila ada peluncuran token protokol tersendiri**. Nominal itu tidak dapat dipakai untuk menghitung reward pribadi. Data tidak memberi jumlah alokasi, pasokan awal, tanggal listing, harga per token, pajak, gas aktual, ataupun peluang peluncuran.

### Rumus dan ketidakpastian

1. Pilih protokol pembanding yang punya identitas token, market cap dan TVL positif. Buang kategori/kata yang mengindikasikan custody atau produk turunan sesuai model. Untuk ID token yang sama, ambil satu record eligible dengan TVL terbesar. Tersisa 89 identitas.
2. Hitung rasio market cap dibagi TVL. Di ruang log, gabungkan median sektor, keluarga bisnis dan seluruh pembanding. Bobot keluarga `m/(m+12)`, bobot sektor `n/(n+6)`. Kategori yang hanya punya satu peer mendapat bobot sektor 1/7.
3. Kalikan TVL kandidat dengan multiple hasil penggabungan. Kalikan lagi dengan faktor pertumbuhan tujuh hari dan faktor umur pencatatan. Faktor pertumbuhan membatasi perubahan ke −50% sampai +100% lalu memakai pangkat 0,35. Umur memberi faktor netral di 365 hari dan berhenti bertambah di 1.095 hari. Data umur atau perubahan yang hilang memberi faktor 1.
4. Bulatkan dolar hanya di akhir. Skenario bawah dan atas memakai kuartil 25 dan 75 dengan langkah yang sama. Ini menunjukkan sebaran pembanding. Tidak ada probabilitas 50% atau 95% yang dilekatkan ke rentang itu.
5. Urutkan dari nilai terbesar. Jika sama persis, slug diurutkan alfabetis. Biaya percobaan dan jumlah langkah farm tidak mengubah rank.

| Rank | Protokol | Dasar, USD | Skenario peer, USD |
| ---: | --- | ---: | ---: |
| 1 | Steakhouse Financial | 780.002.891 | 223.078.623–2.217.070.856 |
| 2 | Gauntlet | 459.064.859 | 131.291.252–1.304.840.444 |
| 3 | USDD | 186.409.982 | 41.148.096–492.137.811 |
| 4 | Veda | 143.804.686 | 44.667.261–386.230.195 |
| 5 | Bittensor dTAO | 138.974.381 | 32.439.629–514.984.374 |

Contoh Steakhouse memakai TVL US$2.753.981.495 × multiple 0,277518 × pertumbuhan 0,992267 × umur 1,028525. Berdasarkan presisi penuh hasilnya US$780.002.891. Sektor Risk Curators hanya memiliki satu peer langsung, dengan 21 peer dalam keluarga bisnisnya. Itu membantu menjelaskan rentang yang lebar. USDD sudah berfungsi sebagai stablecoin dan Bittensor memiliki TAO serta unit alpha. Keduanya masuk radar karena aturan identitas watchlist asli. Produktivitas stablecoin atau subnet tidak membuktikan rencana peluncuran token tambahan.

Dalam uji silang, program mengeluarkan satu token pembanding, menghitung ulang model dari sisanya, lalu membandingkan estimasi dengan kapitalisasi token yang dikeluarkan. Sebanyak **22 dari 89** estimasi berada di antara setengah dan dua kali angka aktual. Median galat multiplikatif **4,30×**. Patokan sederhana berbasis median global menghasilkan **4,71×**. Sampel ini mengukur perbedaan antar-token yang sudah punya market cap. Kit tidak memuat hasil peluncuran di masa depan.

## Pakai dashboard dan farm plan

1. Buka **Radar** lalu klik nama atau baris protokol. Filter bisa digabung berdasarkan chain, sektor, keanggotaan watchlist dan jenis tindakan. Ikon panah pada header tabel mengubah arah pengurutan. Tekan tombol **/** untuk mencari nama.
2. Pada profil, cek **Valuation worksheet** untuk melihat faktor dan peer. Slider menghitung dampak perubahan TVL pada kandidat yang sedang dibuka. Ranking resmi tetap merujuk ke snapshot.
3. Baca enam langkah **Farm playbook**. **85** kandidat mendapat rute uji kecil opsional dan **62** kandidat mendapat rute observasi. Kolom chain menunjukkan jaringan untuk dicek. Filter chain mencakup seluruh jaringan yang terdaftar dalam snapshot.
4. Pada uji kecil, contoh maksimum pokok US$25 sudah tersedia di jaringan terkait. Bandingkan biaya masuk, approval, spread dan keluar dengan batas contoh US$2 atau US$5 untuk Ethereum. Jika minimum atau kuotasi melampaui batas, selesaikan penilaian lewat pratinjau. Waktu 25 menit berarti waktu aktif. Durasi antrean aktual bergantung pada produk.
5. Pada observasi, anggaran pokok dan biaya US$0. Gunakan sekitar 15 menit untuk membaca syarat, mengecek transaksi publik atau membandingkan kuotasi di atas kertas. Pada RWA seperti OpenTrade, cek syarat akses institusional terlebih dahulu.
6. Catat bukti dari penggunaan nyata. Jadwalkan pemeriksaan ulang tujuh hari kemudian atau di tanggal unlock berikutnya. Cocokkan aturan kampanye resmi dengan produk, waktu dan dompet jika memang ada pengumuman.

**Contoh Steakhouse Financial di Base.** Buka direktori resmi kurator di Morpho. Pilih vault USDC yang benar-benar mencantumkan Steakhouse. Catat alamat kontrak, jaminan, APY/fee dan likuiditas untuk keluar. Pratinjau jumlah saham yang diperoleh dari nominal percobaan, lalu pratinjau redeem ke USDC. Jika benar-benar melakukan transaksi, simpan alamat vault, jumlah saham, biaya aktual dan hash. Angka US$2 adalah batas pengeluaran contoh untuk satu putaran, sehingga biaya gas saat itu tetap perlu dicek. [Direktori Steakhouse](https://app.morpho.org/curator/steakhouse-financial)

**Contoh observasi Symbiotic.** Pilih satu vault Ethereum yang terdokumentasi. Identifikasi collateral, operator, konfigurasi slashing dan panjang epoch. Telusuri permintaan keluar yang pernah terjadi, lalu klaim akhirnya. Catat kapan dana mulai bisa diklaim. Riset ini dapat diselesaikan tanpa deposit. [Vault Symbiotic](https://docs.symbiotic.fi/learn/core-concepts/vault)

Semua 40 anggota watchlist memiliki rujukan produk masing-masing. Rute 107 kandidat tambahan merupakan checklist kategori dengan tautan listing untuk memeriksa produk dan jaringan. Panduan lengkap dan mudah dicari per nama ada di **Rencana-Farm-ID.md**.

## Reproduksi di komputermu

Memerlukan Node 22.18 atau lebih baru. Perintah berikut juga bisa dijalankan satu per satu di PowerShell. Dari direktori hasil ekstrak ZIP, jalankan:

```sh
git clone -b submission Meridian-Source.bundle repo-submit
cd repo-submit
node main.ts --input data/snapshot.json --output out
node scripts/verify.mjs out data/snapshot.json
```

Buka **repo-submit/out/dashboard/index.html** untuk melihat hasil build. Untuk memotret ulang, Python dan Playwright diperlukan hanya saat pengambilan screenshot. Script **scripts/capture.py** membuka halaman lokal dalam Chromium, menonaktifkan jaringan, dan mengambil gambar setelah klik dan filter. Instruksi reproduksi screenshot ada di README proyek.

| Pemeriksaan | Hasil |
| --- | --- |
| Integritas input dan vendor | Hash snapshot dan library cocok dengan manifest kit asli |
| Build | Dua run independen di clone dari source bundle, Node 22.18.0, semua 10 file keluaran identik dengan commit |
| Tujuh pemeriksaan file lokal | Struktur dashboard, board, urutan, cakupan, langkah, screenshot dan kesamaan dossier semuanya lulus |
| Dossier | 709.717 byte, di bawah batas 1,5 MiB; source dashboard yang ditampilkan lengkap |
| Interaksi | Semua 147 profil cocok dengan enam langkah di JSON; semua 758 detail bisa dibuka |
| Offline | Browser memuat halaman, mengurutkan, memfilter, berpindah halaman dan menguji slider dengan nol request HTTP maupun HTTPS |
| Screenshot | 3 PNG, masing-masing 1440 × 960, di bawah batas 512 KiB |
| Mobile | Empat tampilan utama diuji pada lebar 390 piksel; tabel mendukung gulir horizontal |
| Tanggal repo | Pemeriksaan resmi mengakui drand round 34202695 diterbitkan 23 November 2026 pukul 12.24 WIB, setelah pembukaan |
| Intake resmi | Transkrip asli belum tersedia. Verifikasi kepemilikan akun dan tanda tangan dilakukan saat pengiriman |

## Status submission dan langkah pemilik wallet

| Field | Nilai |
| --- | --- |
| Kompetisi | token-radar-01 |
| Identitas repo | bundle:652cd5b0cb277ee228510d44b5e1cb92831dd928 |
| Commit | 841c096eeaf74360c6d7a1fa4551b518954a9a3a |
| Branch | submission |
| Wallet publik pada anchor | Buu2jeDHcLfrZgufZLk3zL8Rxi6MRQb5UdMMJLQRvrax |
| SHA-256 file Meridian-Source.bundle | 12ecab78a0fd9791848a214e69391e735bfc6c1544d906de55cdd838f7e95589 |
| Batas pengiriman | 14 Desember 2026 pukul 17.00 WIB |

**Syarat transkrip.** CLI sudah mencoba penemuan lokal dan jalur Codex Cloud untuk repo ini. Sesi build asli yang bisa dipaketkan tidak ditemukan. Jurnal di **bukti/** mendokumentasikan perubahan source yang ditulis saat pengerjaan, keluaran anchor dan pengujian. Panitia membedakan jurnal tersebut dengan rekaman autentik dari klien agen. Di kompetisi ini, sesi yang hanya *handed over* tidak berhak mendapat tempat berhadiah. [Persyaratan transkrip dan kepemilikan](https://make.fun/api/competitions/token-radar-01/requirements)

Jika kamu memang mempunyai rekaman autentik **sesi yang menulis commit ini**, gunakan rekaman tersebut sesuai aturan kit dan periksa bundelnya terlebih dahulu. SDK mengharuskan sesi dan metadata run yang sebenarnya. Jika sesi asli tidak dapat diperoleh sama sekali, jalur hadiah memerlukan pengerjaan baru sejak awal dalam klien yang menyimpan rekaman, lengkap dengan anchor baru sejak awal. Menjalankan hasil jadi kembali hanya membuktikan reproduksibilitas.

Perintah berikut dijalankan dari folder utama hasil ekstrak ZIP, setelah clone di atas. Ganti path contoh dengan lokasi log dan wallet **di perangkatmu sendiri**. Rincian metadata yang dapat dibaca dari log tergantung klien yang merekamnya.

```sh
node kit/cli/makefun.mjs bundle --repo repo-submit --session /path/to/actual-build-session.jsonl --out transcripts.tar.gz
node kit/cli/makefun.mjs check --kit kit --repo repo-submit --commit 841c096eeaf74360c6d7a1fa4551b518954a9a3a --transcripts transcripts.tar.gz
```

Setelah pemeriksaan transkrip lulus, ikuti langkah login atau registrasi make.fun untuk akun pemilik wallet yang tertera pada anchor. Perintah di bawah **mengirim entry dan memakai kuota**. Tanda tangan dilakukan di perangkat pemilik wallet.

```sh
node kit/cli/makefun.mjs submit --competition token-radar-01 --source repo-submit --commit 841c096eeaf74360c6d7a1fa4551b518954a9a3a --title "Protocol Launch Valuations" --bundle transcripts.tar.gz --keypair /path/to/your-local-wallet.json
```

Brief publik menetapkan maksimum lima submission per hari dan sepuluh selama kompetisi. Entry terakhir sebelum penutupan menjadi entry final. Hadiah total US$1.325 dibagi untuk sepuluh posisi. Nilai dan peringkat resmi baru tersedia dari make.fun. [Halaman bounty](https://make.fun/bounty/token-radar-01)
